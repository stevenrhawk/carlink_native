plugins {
    id("com.android.application")
}

android {
    namespace = "com.carlink.cluster.media"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.carlink.cluster.media"
        minSdk = 32
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

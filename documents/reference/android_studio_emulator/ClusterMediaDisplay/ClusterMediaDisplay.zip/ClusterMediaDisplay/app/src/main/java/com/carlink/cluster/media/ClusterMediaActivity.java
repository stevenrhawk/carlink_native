package com.carlink.cluster.media;

import android.app.Activity;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Displays active media session metadata on the AAOS cluster display.
 *
 * Works with any app's MediaSession (CarLink, Spotify, YouTube Music, etc.).
 * Launched by ClusterHomeSample when CLUSTER_SWITCH_UI=2 (music) via RRO override
 * of config_clusterMusicActivity.
 */
public class ClusterMediaActivity extends Activity {

    private static final String TAG = "ClusterMedia";

    private ImageView albumArt;
    private TextView trackTitle;
    private TextView artistName;
    private TextView playbackState;

    private MediaSessionManager mediaSessionManager;
    private MediaController activeController;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            this::onActiveSessionsChanged;

    private final MediaController.Callback controllerCallback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            mainHandler.post(() -> updateMetadata(metadata));
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            mainHandler.post(() -> updatePlaybackState(state));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cluster_media);

        albumArt = findViewById(R.id.album_art);
        trackTitle = findViewById(R.id.track_title);
        artistName = findViewById(R.id.artist_name);
        playbackState = findViewById(R.id.playback_state);

        mediaSessionManager = getSystemService(MediaSessionManager.class);

        try {
            List<MediaController> controllers = mediaSessionManager.getActiveSessions(null);
            onActiveSessionsChanged(controllers);
            mediaSessionManager.addOnActiveSessionsChangedListener(sessionsListener, null);
            Log.i(TAG, "Registered session listener, " + controllers.size() + " active sessions");
        } catch (SecurityException e) {
            Log.e(TAG, "No permission for getActiveSessions: " + e.getMessage());
            trackTitle.setText("No Permission");
            artistName.setText("Grant MEDIA_CONTENT_CONTROL");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (activeController != null) {
            activeController.unregisterCallback(controllerCallback);
            activeController = null;
        }
        try {
            mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsListener);
        } catch (Exception e) {
            Log.w(TAG, "Failed to remove listener: " + e.getMessage());
        }
    }

    private void onActiveSessionsChanged(List<MediaController> controllers) {
        if (controllers == null || controllers.isEmpty()) {
            clearDisplay();
            return;
        }

        // Pick the first active session (highest priority)
        MediaController controller = controllers.get(0);

        // Skip if same controller already tracked
        if (activeController != null &&
                activeController.getSessionToken().equals(controller.getSessionToken())) {
            return;
        }

        // Unregister old controller
        if (activeController != null) {
            activeController.unregisterCallback(controllerCallback);
        }

        activeController = controller;
        activeController.registerCallback(controllerCallback, mainHandler);

        Log.i(TAG, "Tracking session: " + controller.getPackageName());

        // Update immediately with current state
        updateMetadata(controller.getMetadata());
        updatePlaybackState(controller.getPlaybackState());
    }

    private void updateMetadata(MediaMetadata metadata) {
        if (metadata == null) {
            trackTitle.setText("No Media Playing");
            artistName.setText("");
            albumArt.setImageResource(R.drawable.ic_music_note);
            return;
        }

        String title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        Bitmap art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (art == null) {
            art = metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        }

        trackTitle.setText(title != null ? title : "Unknown");
        artistName.setText(artist != null ? artist : "");

        if (art != null) {
            albumArt.setImageBitmap(art);
        } else {
            albumArt.setImageResource(R.drawable.ic_music_note);
        }

        Log.d(TAG, "Metadata: " + title + " - " + artist);
    }

    private void updatePlaybackState(PlaybackState state) {
        if (state == null) {
            playbackState.setText("");
            return;
        }

        switch (state.getState()) {
            case PlaybackState.STATE_PLAYING:
                playbackState.setText("Now Playing");
                playbackState.setTextColor(0xFF4CAF50); // green
                break;
            case PlaybackState.STATE_PAUSED:
                playbackState.setText("Paused");
                playbackState.setTextColor(0xFFFF9800); // orange
                break;
            case PlaybackState.STATE_STOPPED:
                playbackState.setText("Stopped");
                playbackState.setTextColor(0xFF666666);
                break;
            case PlaybackState.STATE_BUFFERING:
                playbackState.setText("Buffering...");
                playbackState.setTextColor(0xFF666666);
                break;
            default:
                playbackState.setText("");
                break;
        }
    }

    private void clearDisplay() {
        trackTitle.setText("No Media Playing");
        artistName.setText("");
        playbackState.setText("");
        albumArt.setImageResource(R.drawable.ic_music_note);

        if (activeController != null) {
            activeController.unregisterCallback(controllerCallback);
            activeController = null;
        }
    }
}

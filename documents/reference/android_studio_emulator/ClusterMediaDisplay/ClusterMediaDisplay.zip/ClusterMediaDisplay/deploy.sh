#!/bin/bash
#
# Deploy ClusterMediaDisplay to AAOS emulator
#
# Prerequisites:
#   - AAOS emulator running with cluster display
#   - adb root and adb remount available
#   - App built: ./gradlew assembleDebug
#
# Usage: ./deploy.sh [SERIAL]
#   SERIAL: emulator serial (default: emulator-5554)

set -e

SERIAL="${1:-emulator-5554}"
ANDROID_HOME="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
ADB="$ANDROID_HOME/platform-tools/adb -s $SERIAL"

APK="app/build/outputs/apk/debug/app-debug.apk"
OVERLAY_APK="overlay/CarlinkClusterOverlay.apk"
PERMISSIONS="permissions/privapp-permissions-clustermedia.xml"

# Verify files exist
for f in "$APK" "$OVERLAY_APK" "$PERMISSIONS"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: $f not found. Build first: ./gradlew assembleDebug"
        exit 1
    fi
done

echo "=== Deploying ClusterMediaDisplay to $SERIAL ==="

# Root and remount
echo "[1/5] Rooting and remounting..."
$ADB root 2>/dev/null || true
sleep 2
$ADB remount 2>/dev/null || true

# Install priv-app
echo "[2/5] Installing priv-app..."
$ADB shell mkdir -p /system/priv-app/ClusterMediaDisplay
$ADB push "$APK" /system/priv-app/ClusterMediaDisplay/ClusterMediaDisplay.apk

# Install permissions
echo "[3/5] Installing privapp permissions..."
$ADB push "$PERMISSIONS" /system/etc/permissions/privapp-permissions-clustermedia.xml

# Install RRO overlay
echo "[4/5] Installing RRO overlay..."
$ADB shell mkdir -p /product/overlay/CarlinkClusterOverlay
$ADB push "$OVERLAY_APK" /product/overlay/CarlinkClusterOverlay/CarlinkClusterOverlay.apk

# Reboot
echo "[5/5] Rebooting..."
$ADB reboot
echo ""
echo "Waiting for boot..."
$ADB wait-for-device
sleep 15

# Wait for boot_completed
for i in $(seq 1 30); do
    BOOT=$($ADB shell getprop sys.boot_completed 2>/dev/null || echo "0")
    if [ "$BOOT" = "1" ]; then
        break
    fi
    sleep 2
done

echo ""
echo "=== Verifying ==="
echo ""

# Verify overlay
echo "Overlay status:"
$ADB shell cmd overlay list com.android.car.cluster.home 2>/dev/null || echo "  (unable to check)"
echo ""

# Verify package
echo "Package installed:"
$ADB shell pm list packages | grep carlink.cluster.media || echo "  NOT FOUND"
echo ""

# Verify permission
echo "Permission:"
$ADB shell dumpsys package com.carlink.cluster.media | grep "MEDIA_CONTENT_CONTROL" | head -2 || echo "  NOT FOUND"
echo ""

echo "=== Done ==="
echo ""
echo "To switch cluster to music view:"
echo "  adb -s $SERIAL shell cmd car_service inject-vhal-event 0x11400F34 2"
echo ""
echo "To switch back to home:"
echo "  adb -s $SERIAL shell cmd car_service inject-vhal-event 0x11400F34 0"
